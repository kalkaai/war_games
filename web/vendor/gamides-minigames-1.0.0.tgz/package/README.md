# `@gamides/minigames` — 100 Universal Mini-Games Engine (Phaser 3)

Standalone Vite + TypeScript + Phaser 3 mini-games engine powering 100 survival, base-building, and zombie combat mini-games for **GAMIDES** (`gamides.com`).

## Architecture Highlights

- **Universal URL Router (`src/router/urlRouter.ts`):** Parses `/play/:slug`, `?game=:slug`, hash routes, and canonical slug aliases.
- **Dynamic Asset Loader (`src/engine/DynamicAssetLoader.ts`):** Lazy-loads only the active game's JSON config (`~1.6 KB`) and only the single active gameplay template chunk (`~3–6 KB`), keeping per-game payloads strictly under 1MB.
- **10 Physics & Logic Templates (`src/templates/`):**
  1. `gravity-tap` (#1–10: *Flappy Zombie*, *Chopper Escape*, etc.)
  2. `lane-runner` (#11–20: *Wasteland Dash*, *Supply Truck Run*, etc.)
  3. `physics-catcher` (#21–30: *Airdrop Catcher*, *Ammo Grab*, etc.)
  4. `timing-precision` (#31–40: *Sniper Aim*, *Lockpick Pro*, etc.)
  5. `tower-stacker` (#41–50: *Barricade Builder*, *HQ Constructor*, etc.)
  6. `defender-360` (#51–60: *Zombie Sniper 360*, *Turret Defense*, etc.)
  7. `grid-swipe` (#61–70: *Ammo Merge*, *Base Builder 2048*, etc.)
  8. `reaction-whack` (#71–80: *Whack-a-Zombie*, *Target Practice*, etc.)
  9. `endless-jumper` (#81–90: *Tower Escape*, *Shaft Climber*, etc.)
  10. `slingshot-physics` (#91–100: *Grenade Toss*, *Catapult Defense*, etc.)
- **Programmatic 2D Sprite Atlas Generator (`src/assets/AtlasGenerator.ts`):** Synthesizes crisp 2D survival/zombie/military sprites onto offscreen HTML5 canvases at runtime with zero external PNG network overhead.
- **Procedural WebAudio SFX (`src/audio/SoundFX.ts`):** Zero-dependency sound synthesizer.

## Commands

```bash
npm run dev             # Launch standalone Vite dev harness at http://localhost:5173
npm test                # Run Vitest unit tests
npm run validate        # Validate all 100 JSON configs, difficulty curves, and <1MB budget
npm run build:artifact  # Compile library + types and emit gamides-minigames-1.0.0.tgz
```
